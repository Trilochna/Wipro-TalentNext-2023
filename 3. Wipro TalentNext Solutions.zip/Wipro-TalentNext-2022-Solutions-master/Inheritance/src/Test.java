// 1 c

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bird bird = new Bird();
		bird.eat();
		bird.sleep();
		bird.fly();

	}

}
