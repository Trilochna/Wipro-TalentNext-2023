// 7

public class CheckXInString {
	public static void main(String[] args) {

		String str = "xHix";

		if (str.charAt(0) == 'x' && str.charAt(str.length() - 1) == 'x') {
			System.out.println(str.substring(1, str.length() - 1));

			return;
		}

		System.out.println(str);

	}
}
