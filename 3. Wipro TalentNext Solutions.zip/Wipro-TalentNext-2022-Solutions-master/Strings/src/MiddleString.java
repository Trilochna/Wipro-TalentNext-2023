// 5

public class MiddleString {

	public static void main(String[] args) {
		String str = "abcd";

		System.out.println(str.substring(1, str.length() - 1));
	}

}
