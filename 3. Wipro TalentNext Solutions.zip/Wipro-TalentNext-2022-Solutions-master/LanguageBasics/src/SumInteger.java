// 3

public class SumInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = Integer.valueOf(args[0]);
        int b = Integer.valueOf(args[1]);

        System.out.println("The sum of " + a + " and " + b + " is " + (a + b));
	}

}
