// 1
public class StringsMerge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		System.out.println(args[0]+" Technologies " + args[1]);

	}

}
