// 2 

package com.wipro.automobile.ship;

public class Compartment {
	public int height;
	public int width;
	public int length;
}
