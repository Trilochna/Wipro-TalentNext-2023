// 15

public class FloydsPyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 3;

		for (int i = 0; i < x; i++) {
			for (int j = 0; j < i + 1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
