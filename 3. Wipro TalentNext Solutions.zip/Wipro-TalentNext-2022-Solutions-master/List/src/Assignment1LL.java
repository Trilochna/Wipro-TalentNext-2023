// 5

import java.util.LinkedList;

public class Assignment1LL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> list = new LinkedList<>();

		list.add("jan");
		list.add("feb");
		list.add("mar");
		list.add("apr");
		list.add("may");
		list.add("jun");
		list.add("jul");
		list.add("aug");
		list.add("sep");
		list.add("oct");
		list.add("nov");
		list.add("dec");

		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}

	}

}
