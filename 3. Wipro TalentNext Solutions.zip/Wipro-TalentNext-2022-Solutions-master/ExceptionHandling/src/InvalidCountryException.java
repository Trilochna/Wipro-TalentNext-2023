// 4 a

public class InvalidCountryException extends Exception{
	
	public InvalidCountryException() {
		System.out.println("Only available for India");
	}
}
