// 3 a

public class NegativeValueException extends Exception {
	
	public NegativeValueException(String errorMessage) {
		super(errorMessage);
	}

}
