// 1 b

public class Test {

	public static void main(String[] args) {
		Box box = new Box(2, 3, 4);
		System.out.println(box.volume());
	}
	
}
