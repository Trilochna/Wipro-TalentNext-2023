// 1 b

public class Apple extends Fruit {

	@Override
	public void eat() {
		System.out.println("The apple tastes sweet");
	}

}
