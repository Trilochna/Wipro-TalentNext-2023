// 2 b

public class Test {
	public static void main(String[] args) {
		Shape shape = new Shape();
		Shape.Circle  circle = new Shape.Circle();
		circle.draw();
	}
}
