// 2 

public class intToOctaHex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x = 100;
		
		System.out.println(Integer.toHexString(x));
		System.out.println(Integer.toBinaryString(x));
		System.out.println(Integer.toOctalString(x));

	}

}
