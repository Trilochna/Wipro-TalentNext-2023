// 1 b

public class FirstClass extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return new String("FirstClass");
	}

}
